# Autores:
- Felipe Pfeifer Rubin
- Ian Aragon Escobar
- T1 CG 2018/1


# Arquivos:
4 casos de teste, com os respectivos videos gerados pela ferramenta ffmpeg supondo 30FPS .

Paises:
- Austria:
- França:
- Alemanha:
- Brasil:
Para cada pais .mp4 é o video e .txt eh o PATH_D

- Relatorio.pdf eh o relatorio.


